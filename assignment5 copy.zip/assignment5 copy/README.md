Assignment4 - Module 5 
Coursera course: HTML, CSS, and Javascript for Web Developers

Console output [HERE](https://denismorayta.github.io/coursera-test/assignment5/index.html)